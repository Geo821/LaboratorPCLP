#include <stdio.h>
#include <stdlib.h>
#include "geolib.h"

int* read_array(int size)
{
    int *a;
    a = (int*) malloc(size*sizeof(int));
    printf("Insert %d numbers: \n",size);
    for(int i=0;i<size;i++)
        scanf("%d",&*(a+i));
    return a;
}

void print_array(int *a,int size)
{
    for(int i=0;i<size;i++)
        printf("%d ",*(a+i)); 
    printf("\n"); 
}