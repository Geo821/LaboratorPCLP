#ifndef GEOLIB_H // checks if the library exists in the project already
#define GEOLIB_H // adds the library to the project

int *read_array(int size);
void print_array(int *a,int size);

#endif // stops checking